module UserCourseHelper
end
