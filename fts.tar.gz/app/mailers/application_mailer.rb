class ApplicationMailer < ActionMailer::Base
  default from: "thanhtungcnttk13@gmail.com"
  layout "mailer"
end
