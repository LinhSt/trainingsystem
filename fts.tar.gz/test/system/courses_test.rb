require "application_system_test_case"

class CoursesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit courses_url
  #
  #   assert_selector "h1", text: "Course"
  # end
end
